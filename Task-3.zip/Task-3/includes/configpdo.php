<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "Database_srms";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>